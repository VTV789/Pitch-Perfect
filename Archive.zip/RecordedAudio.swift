//
//  RecordedAudio.swift
//  Pitch Perfect
//
//  Created by Vinh Vu on 11/20/15.
//  Copyright © 2015 Vinh. All rights reserved.
//

import Foundation

class RecordedAudio: NSObject{
    var filePathUrl: NSURL!
    var title: String!
    
    init (x: NSURL!, y: String!){
        filePathUrl = x
        title = y
    }
}


